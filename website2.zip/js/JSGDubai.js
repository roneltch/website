

function ShowFloor1Dubai()
{
   document.getElementById("floor1Dubai").style.display = "block";
   document.getElementById("floor2Dubai").style.display = "none";
   document.getElementById("floor3Dubai").style.display = "none";
}

function ShowFloor2Dubai()
{
   document.getElementById("floor1Dubai").style.display = "none";
   document.getElementById("floor2Dubai").style.display = "block";
   document.getElementById("floor3Dubai").style.display = "none";
}

function ShowFloor3Dubai()
{
   document.getElementById("floor1Dubai").style.display = "none";
   document.getElementById("floor2Dubai").style.display = "none";
   document.getElementById("floor3Dubai").style.display = "block";
}



 