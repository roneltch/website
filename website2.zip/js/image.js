const firebaseConfig = {
    apiKey: "AIzaSyCmqwtHL7TTy58xoS5SIHvEmTageVjK4jc",
    authDomain: "iot-project-12fdb.firebaseapp.com",
    databaseURL: "https://iot-project-12fdb-default-rtdb.firebaseio.com",
    projectId: "iot-project-12fdb",
    storageBucket: "iot-project-12fdb.appspot.com",
    messagingSenderId: "46895724359",
    appId: "1:46895724359:web:5101b987990f85bbf1be62"
  };
  corentUser = {}
const app = firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const storage = firebase.storage();
const database = firebase.database();



function saveImgOnDB(img,Callback){
    // Create a root reference
    var userRef = firebase.storage().ref(corentUser.uuid+'/test.jpg');

    userRef.put(img).then((snapshot) => {
      snapshot.ref.getDownloadURL().then((downloadURL) => {
        console.log('File available at', downloadURL);
        Callback(downloadURL)
      });
    });
    

}
function createUser(){

  corentUser.mail = document.getElementById("email").value
  corentUser.pass = document.getElementById("pass").value
  // if(!validatePassEndEmail(mail , pass)){
  //   console.log("invalid user name or password")
  //   return
  // }
  // email = document.getElementById("pass2").value
  img = document.getElementById("img").files[0]

  createUserOnDB(img)
  
  
}
function saveUserOnRTDB(){
  database.ref('users/' + corentUser.uuid).set(corentUser);

}
function createUserOnDB(userImg){

  auth.createUserWithEmailAndPassword(corentUser.mail, corentUser.pass)
  .then((userCredential) => {
    // Signed in 
    var user = userCredential.user;
    corentUser.uuid = user.uid
    console.log(user)
   
    saveImgOnDB(userImg,(imgUrl)=>{
      corentUser.img = imgUrl
      console.log(corentUser)
      saveUserOnRTDB()
    })
    
    // ...
  })
  .catch((error) => {
    var errorCode = error.code;
    var errorMessage = error.message;
    console.log(errorMessage)
    // ..
  });
}

function signIn(){

  em  = document.getElementById("signInem").value
  pass = document.getElementById("signInPass").value
  auth.signInWithEmailAndPassword(em, pass)
  .then((userCredential) => {
    // Signed in
    corentUser.uuid = userCredential.user;
    // ...
  })
  .catch((error) => {
    var errorCode = error.code;
    var errorMessage = error.message;
  });
}
const imgBTN = document.getElementById("esp-cam")
imgBTN.onclick = ()=>{
   //ml5 img clasifier
   classifier = ml5.imageClassifier('MobileNet',()=>{
    
    //img = loadImage(img.src);
    classifier.classify(img, (error,result)=>{
        if(error){
          console.log(error)
          return
        }
        console.log(result)
    });
  });
}
//esp-cam ip on 
// var ipRef = database.ref('/ip' );
// ipRef.on('value', (snapshot) => {
//   const data = snapshot.val();
//   console.log(data)
  img = document.getElementById("esp-cam")
  img.src = `http://10.9.20.78:81/stream`

 
// });
// esp32 tempertur on
var starCountRef = database.ref('sensors/temp' );
starCountRef.on('value', (snapshot) => {
  const data = snapshot.val();
  console.log(data.curent)
  updateTempUi(data.curent);
});

function updateTempUi(data){
  
  new RGraph.Thermometer({
    id: 'cvs',
    min: 0,
    max: 80,
    value: data,
    options: {
        marginLeft: 60,
        marginRight: 70,
        colors: ['red'],
         tooltips: '<span style="font-size: 5pt">Todays temperature</span><br/>%{key}',
         textSize:8,
         labelsValue:false,
         labelsOffsety:5,
         scaleVisible:true,
         // tooltipsFormattedKeyLabels: ['London'],
        // tooltipsFormattedUnitsPost: '°',
        // tooltipsCss: {
        //     fontSize: '10pt',
        //     textAlign: 'left'
        // }
        //  textAccessible: true
    }
  }).draw();
}


