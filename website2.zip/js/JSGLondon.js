

function ShowFloor1London()
{
   document.getElementById("floor1London").style.display = "block";
   document.getElementById("floor2London").style.display = "none";
   document.getElementById("floor3London").style.display = "none";
}

function ShowFloor2London()
{
   document.getElementById("floor1London").style.display = "none";
   document.getElementById("floor2London").style.display = "block";
   document.getElementById("floor3London").style.display = "none";
}

function ShowFloor3London()
{
   document.getElementById("floor1London").style.display = "none";
   document.getElementById("floor2London").style.display = "none";
   document.getElementById("floor3London").style.display = "block";
}
