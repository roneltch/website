// import { getDatabase, ref, child, push, update } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyAXeQrok-FgHkLcF-Uiy0Op9Zpqq67GU20",
  authDomain: "foodmaster-2750f.firebaseapp.com",
  databaseURL: "https://foodmaster-2750f-default-rtdb.firebaseio.com",
  projectId: "foodmaster-2750f",
  storageBucket: "foodmaster-2750f.appspot.com",
  messagingSenderId: "326531598940",
  appId: "1:326531598940:web:9457464e08b8e7efceb499",
  measurementId: "G-418MD08GJZ"
};

// Get a reference to the specific fridge's drawers
currentUser = {};
const app = firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const storage = firebase.storage();
const database = firebase.database();

function saveImgOnDB(img, Callback) {
  // Create a root reference
  var userRef = firebase.storage().ref(currentUser.uuid + "/test.jpg");

  userRef.put(img).then((snapshot) => {
    snapshot.ref.getDownloadURL().then((downloadURL) => {
      console.log("File available at", downloadURL);
      Callback(downloadURL);
    });
  });
}

function createUser() {
  currentUser.mail = document.getElementById("email").value;
  currentUser.pass = document.getElementById("pass").value;
  // if(!validatePassEndEmail(mail , pass)){
  //   console.log("invalid user name or password")
  //   return
  // }
  // email = document.getElementById("pass2").value
  if (document.getElementById("img").files[0]) {
    img = document.getElementById("img").files[0];
  } else {
    img = document.getElementById("img").value;
    console.log(img);
  }

  createUserOnDB(img);
}
function saveUserOnRTDB() {
  database.ref("users/" + currentUser.uuid).set(currentUser);
}
function createUserOnDB(userImg) {
  auth
    .createUserWithEmailAndPassword(currentUser.mail, currentUser.pass)
    .then((userCredential) => {
      // Signed in
      var user = userCredential.user;
      currentUser.uuid = user.uid;
      console.log(user);

      saveImgOnDB(userImg, (imgUrl) => {
        currentUser.img = imgUrl;
        console.log(currentUser);
        saveUserOnRTDB();
      });

      // ...
    })
    .catch((error) => {
      var errorCode = error.code;
      var errorMessage = error.message;
      console.log(errorMessage);
      // ..
    });
}


function signInOnLoad() {
  em = currentUser.uid.email;
  pass = currentUser.pass;
  auth
    .signInWithEmailAndPassword(em, pass)
    .then((userCredential) => {
      // Signed in
      currentUser.uuid = userCredential.user;
      console.log("Logged IN");
      console.log(currentUser.uuid);
      userLoggedIn(currentUser.uuid.email);
      // ...
    })
    .catch((error) => {
      var errorCode = error.code;
      var errorMessage = error.message;
    });
}

function userLoggedIn(email) {
  console.log("works");
  document.getElementById("dropdownMenuButton").innerHTML = email;
  document.getElementById("sign-ul").classList = "d-none";
  document.getElementById("shop").classList.remove("d-none");
  document.getElementById("fridge").classList.remove("d-none");
  document.getElementById("logged-in").classList.remove("d-none");
  document.getElementById("shop").innerHTML = `SHOP`
}
function signIn() {
  em = document.getElementById("signInem").value;
  pass = document.getElementById("signInPass").value;
  auth
    .signInWithEmailAndPassword(em, pass)
    .then((userCredential) => {
      // Signed in
      currentUser.uuid = userCredential.user;
      currentUser.pass= pass;
      console.log("Logged IN");
      console.log(currentUser.uuid);
      userLoggedIn(currentUser.uuid.email);
      // ...
    })
    .catch((error) => {
      var errorCode = error.code;
      var errorMessage = error.message;
    });
}

function userLoggedIn(email) {
  console.log("works");
  document.getElementById("user-dropdown").innerHTML = email;
  document.getElementById("sign-ul").classList = "d-none";
  document.getElementById("shop").classList.remove("d-none");
  document.getElementById("fridge").classList.remove("d-none");
  document.getElementById("logged-in").classList.remove("d-none");
}


      function insertTableRow(data) {
        console.log("hgf")
        var table = document.getElementById("table");
        var row = table.insertRow();
        row.innerHTML = `
          <tr class="bg-light">
            <th scope="row" class="">
              <div class="d-flex align-items-center">
                <img src="${data.img}" class="img-fluid rounded-3" style="width: 120px;" alt="Book">
                <div class="flex-column ms-4">
                  <p class="mb-2">${data.name}</p>
                </div>
              </div>
            </th>
            <td class="align-middle">
              <div class="d-flex flex-row">
                <button class="btn  px-2" onclick="this.parentNode.querySelector('input[type=number]').stepDown()">
                 -
                </button>
                <input id="form1" min="0" name="quantity" value="1" type="number" class="form-control form-control-sm" style="width: 50px;">
                <button class="btn  px-2" onclick="this.parentNode.querySelector('input[type=number]').stepUp()">
                  +
                </button>
              </div>
            </td>
            <td class="align-middle">
              <p class="mb-0" style="font-weight: 500;">${data.price}</p>
            </td>
            <td class="align-middle">
              <button class="btn btn-dark me-5" onclick="deleteitem(this)">delete</button>
            </td>
          </tr>
        `;
      }

      function fetchDataAndInsertRows() {
        var ref = database.ref("Fridges/FridgeID/Cart");
        ref.once("value").then(function (snapshot) {
          snapshot.forEach(function (childSnapshot) {
            var data = childSnapshot.val();
            insertTableRow(data);
          });
        });
      }

      function fetchDataAndInsertDrawers() {
        let index = 0;
        var ref = database.ref("Fridges/FridgeID/Drawers");
        ref.once("value").then(function (snapshot) {
          snapshot.forEach(function (childSnapshot) {
            index++;
            var data = childSnapshot.val();
            insertdrawers(data,index);
          });
        });
      }

      function gettemp() {
        var ref = database.ref("Sensors/TempSens");
        ref.once("value").then(function (snapshot) {
          var temp = document.getElementById("temp");
          var tempVal = snapshot.child("temp").val();
          temp.innerHTML = `temp: ${tempVal}`;
      
          var humidity = document.getElementById("humidity");
          var humidityVal = snapshot.child("humiddity").val();
          humidity.innerHTML = `humidity: ${humidityVal}`;
        });
      }
      function insertdrawers(data,index) {

        console.log("hgf")
        var dn = document.getElementById("dn"+index);
        var dex = document.getElementById("dex"+index);
        var dim = document.getElementById("dim"+index);
        dn.innerHTML=`${data.name}`
        dex.innerHTML=`${data.expiredDate}`
        dim.src = `${data.img}`
       
      }
      function  updatedrawer(data,number){
        firebase.database().ref("Orders/" + ordernum + "/items/" + index).set(data);

      }
      function order() {
        var ordernum;
        var ref = database.ref("Orders");
        ref.once("value").then(function(snapshot) {
          // Get the last order number and add 1 to get the new order number
          ordernum = snapshot.numChildren() + 1;
          var index = 0;
          // Push the new order number to the "Orders" node
          var cartRef = database.ref("Fridges/FridgeID/Cart");
          cartRef.once("value").then(function(snapshot) {
            snapshot.forEach(function(childSnapshot) {
              var data = childSnapshot.val();
              // Insert each item in the cart to the new order
              insertorder(data, ordernum, index);
              index++;
            });
          });
        });
      }
      
      function insertorder(data, ordernum, index) {
        // Push a new key to the order's items and set its value to the item's name
        firebase.database().ref("Orders/" + ordernum + "/items/" + index).set(data);
      }

      function deleteitem(e){
        var row = e.parent().parent();
        var index = -1;
        var rows = document.getElementById("table").rows;
        for (var i=0;i<rows.length; i++){
            if ( rows[i] == row ){
                index = i;
                break;
            }
        }
       
        var ref = database.ref("Fridges/FridgeID/Cart");
        ref.child(index).remove();
      }

function saveUserOnRTDB(){
    firebase.database().ref('users/' + corentUser.uid).set(corentUser);
}

function edit(){
  window.location.href = "edit.html";
  // var number = document.getElementById("number");
  // number.value = e.value
}
function editdrawer(){
    var number = document.getElementById("number").value;
    var product = document.getElementById("product").value;
    var ref = database.ref("Products/" + product + '/img');
    ref.on("value", (snapshot) => {
      
      var data = snapshot.val();
      firebase.database().ref('Fridges/FridgeID/Drawers/Drawer' + number +'/img').set(data);

      firebase.database().ref('Fridges/FridgeID/Drawers/Drawer' + number +'/name').set(product);
      window.location.href = "fridge.html";

    })

   

    
  
}  
          
