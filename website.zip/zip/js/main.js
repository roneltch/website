
              //London
              const LondonPie = document.getElementById('LondonPie');
            var total = 36;
            var Available = 33;
            var Unavailable = total- Available;
              new Chart(LondonPie, {
                type: 'pie',
                data: {
                  labels: ['Available: ' + Available,'Unavailable: '+ Unavailable],
                  datasets: [{
                    label: '',
                    data: [Available, Unavailable],
                    backgroundColor: [
                        '#e37b1e',
                        '#231f20'
                      
                    ],
                    borderWidth: 0
                  }]
                }
              });


              const LondonLine = document.getElementById('LondonLine');

            new Chart(LondonLine, {
                type: 'line',
                data: {
                labels: ['00:00', '03:00', '06:00', '9:00', '12:00', '15:00', '18:00', '21:00'],
                datasets: [{
                    label: 'busy hours',
                    data: [12, 19, 3, 5, 2, 3,7,2],
                    backgroundColor: [
                       
                        '#231f20'
                      
                    ],
                    borderWidth: 1
                }]
                },
                
            
            });

            const LondonBar = document.getElementById('LondonBar');

            new Chart(LondonBar, {
                type: 'bar',
                data: {
                labels: ['subscribed', 'not subscribed'],
                datasets: [{
                    label: 'subscribed',
                    data: [5, 31],
                    backgroundColor: [
                        
                        '#231f20',
                        '#e37b1e'
                      
                    ],
                    borderWidth: 1
                }]
                },
             
            
            });











              //Dubai
              const DubaiPie = document.getElementById('DubaiPie');
                new Chart(DubaiPie, {
                  type: 'pie',
                  data: {
                    labels: ['Available: ' + 6 ,'Unavailable: ' + 30],
                    datasets: [{
                      label: '',
                      data: [6, 30],
                      backgroundColor: [
                          '#e37b1e',
                          '#231f20'
                        
                      ],
                      borderWidth: 0
                    }]
                  }
                });
  
  
                const DubaiLine = document.getElementById('DubaiLine');
  
              new Chart(DubaiLine, {
                  type: 'line',
                  data: {
                  labels: ['00:00', '03:00', '06:00', '9:00', '12:00', '15:00', '18:00', '21:00'],
                  datasets: [{
                      label: 'busy hours',
                      data: [12, 0, 3, 0, 0, 3,30,2],
                      backgroundColor: [
                         
                          '#231f20'
                        
                      ],
                      borderWidth: 1
                  }]
                  },
                  
              
              });
  
              const DubaiBar = document.getElementById('DubaiBar');
  
              new Chart(DubaiBar, {
                  type: 'bar',
                  data: {
                  labels: ['subscribed', 'not subscribed'],
                  datasets: [{
                      label: 'subscribed',
                      data: [15, 21],
                      backgroundColor: [
                          
                          '#231f20',
                          '#e37b1e'
                        
                      ],
                      borderWidth: 1
                  }]
                  },
               
              
              });

              










              
              //Moscow
              const MoscowPie = document.getElementById('MoscowPie');
                new Chart(MoscowPie, {
                  type: 'pie',
                  data: {
                    labels: ['Available: ' + 20 ,'Unavailable: ' + 16],
                    datasets: [{
                      label: '',
                      data: [20, 16],
                      backgroundColor: [
                          '#e37b1e',
                          '#231f20'
                        
                      ],
                      borderWidth: 0
                    }]
                  }
                });
  
  
                const MoscowLine = document.getElementById('MoscowLine');
  
              new Chart(MoscowLine, {
                  type: 'line',
                  data: {
                  labels: ['00:00', '03:00', '06:00', '9:00', '12:00', '15:00', '18:00', '21:00'],
                  datasets: [{
                      label: 'busy hours',
                      data: [12, 12, 3, 30, 1, 3,0,2],
                      backgroundColor: [
                         
                          '#231f20'
                        
                      ],
                      borderWidth: 1
                  }]
                  },
                  
              
              });
  
              const MoscowBar = document.getElementById('MoscowBar');
  
              new Chart(MoscowBar, {
                  type: 'bar',
                  data: {
                  labels: ['subscribed', 'not subscribed'],
                  datasets: [{
                      label: 'subscribed',
                      data: [8, 28],
                      backgroundColor: [
                          
                          '#231f20',
                          '#e37b1e'
                        
                      ],
                      borderWidth: 1
                  }]
                  },
               
              
              });














              //Tel Aviv
              const TelAvivPie = document.getElementById('TelAvivPie');
                new Chart(TelAvivPie, {
                  type: 'pie',
                  data: {
                    labels: ['Available: ' + 28 ,'Unavailable: ' + 8],
                    datasets: [{
                      label: '',
                      data: [28, 8],
                      backgroundColor: [
                          '#e37b1e',
                          '#231f20'
                        
                      ],
                      borderWidth: 0
                    }]
                  }
                });
  
  
                const TelAvivLine = document.getElementById('TelAvivLine');
  
              new Chart(TelAvivLine, {
                  type: 'line',
                  data: {
                  labels: ['00:00', '03:00', '06:00', '9:00', '12:00', '15:00', '18:00', '21:00'],
                  datasets: [{
                      label: 'busy hours',
                      data: [5, 13, 12, 30, 15, 17,8,3],
                      backgroundColor: [
                         
                          '#231f20'
                        
                      ],
                      borderWidth: 1
                  }]
                  },
                  
              
              });
  
              const TelAvivBar = document.getElementById('TelAvivBar');
  
              new Chart(TelAvivBar, {
                  type: 'bar',
                  data: {
                  labels: ['subscribed', 'not subscribed'],
                  datasets: [{
                      label: 'subscribed',
                      data: [17, 19],
                      backgroundColor: [
                          
                          '#231f20',
                          '#e37b1e'
                        
                      ],
                      borderWidth: 1
                  }]
                  },
               
              
              });

            