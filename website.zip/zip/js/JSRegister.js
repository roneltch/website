const firebaseConfig = {
    apiKey: "AIzaSyCmqwtHL7TTy58xoS5SIHvEmTageVjK4jc",
    authDomain: "iot-project-12fdb.firebaseapp.com",
    databaseURL: "https://iot-project-12fdb-default-rtdb.firebaseio.com",
    projectId: "iot-project-12fdb",
    storageBucket: "iot-project-12fdb.appspot.com",
    messagingSenderId: "46895724359",
    appId: "1:46895724359:web:5101b987990f85bbf1be62"
  };
  
  // Initialize Firebase
  
    // Initialize Firebase
    const app = firebase.initializeApp(firebaseConfig);
    corentUser = {}
    const out = firebase.auth()
    const storage = firebase.storage();
    const database = firebase.database();
  
  
  
  
    function createUser(){
      corentUser.mail = document.getElementById('email').value 
      pass = document.getElementById('email').value 
      // img = document.getElementById("file").files[0]
  
      // if(!validateUserAndPassword(pass1,pass2,mail)){
      //     return
      // }
  
      createUserOnDB(pass)
  
    }
  
  function saveUserOnRTDB(){
      firebase.database().ref('users/' + corentUser.uid).set(corentUser);
  }
  function createUserOnDB(pass,){
      firebase.auth().createUserWithEmailAndPassword(corentUser.mail, pass)
    .then((userCredential) => {
      // Signed in 
      var user = userCredential.user;
      corentUser.uid = user.uid
      console.log(user.uid)
      
      // ...
    })
    .catch((error) => {
      var errorCode = error.code;
      var errorMessage = error.message;
      // ..
    });
  }
  